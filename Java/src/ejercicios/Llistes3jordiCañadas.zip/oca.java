package ejercicios;

import java.util.*;

public class oca {
	
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random rand = new Random();
        List<Integer> casillas = new ArrayList<>(Arrays.asList(
			0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10, 11, 12, 13, 14, 15, 16, 17, 18, 19,20, 21, 22, 23, 24, 25, 26, 27, 28, 29,31,32));
        //menu
        int pj = 0;
        
        
        menu();
        while(menu() != 0) {
        if(menu() == 1) {
        	casillas = new ArrayList<>(Arrays.asList(0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10, 11, 12, 13, 14, 15, 16, 17, 18, 19,20, 21, 22, 23, 24, 25, 26, 27, 28, 29,31,32));
        	pj = 0;
		}
		else if(menu() == 2) {
			int casilla1 = sc.nextInt();
			int casilla2 = sc.nextInt();
			if (casillas.get(casilla1) == 0 && casillas.get(casilla1) == 0){
				casillas.set(casilla1, casilla2);
				casillas.set(casilla2, casilla1);				
			}else {
				System.out.println("Error");
			}
		}
		else if(menu() == 3) {
			for (int i = 0; i < 32; i ++) {
				System.out.print(casillas.get(i));
				if(pj == i) {
					System.out.print("X");
				}
				System.out.println();
			}
		}
		else if(menu() == 4) {
			System.out.println("Posicio actual: " + pj);
			int tirada = ((int)(Math.random() * 6) + 1);
			pj = pj + tirada;
			if(pj == 32) {
				System.out.println("Has guanyat");
			}
			
		}
		else if(menu() == 0) {
			System.out.println("Sortint del joc...");			
		}
        menu();
        }        
    } // Fin main
    static int  menu() {
		Scanner sc = new Scanner(System.in);
		System.out.println("1. Inicializar");
		System.out.println("2. Aparellar");
		System.out.println("3. Veure Joc");
		System.out.println("4. Llençar");
		System.out.println("0. Sortir");
		int input = sc.nextInt();
		return input;
	}    
}
